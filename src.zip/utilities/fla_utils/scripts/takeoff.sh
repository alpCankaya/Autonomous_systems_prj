rostopic pub -1 /flight/event fla_msgs/FlightEvent "header:
  seq: 0
  stamp:
    secs: 0
    nsecs: 0
  frame_id: ''
event_id: 1"
